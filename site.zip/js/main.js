(function(){
var d=document,$=function(s,r){return(r||d).querySelector(s)},$$=function(s,r){return Array.prototype.slice.call((r||d).querySelectorAll(s))};
var reduz=matchMedia('(prefers-reduced-motion: reduce)').matches,fino=matchMedia('(pointer:fine)').matches;

/* menu no celular */
var mb=$('.menu-btn'),nav=$('header nav');
if(mb){mb.addEventListener('click',function(){var o=nav.classList.toggle('open');mb.setAttribute('aria-expanded',o)});}

/* revelar ao rolar */
if('IntersectionObserver' in window){
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.15});
  $$('.rv').forEach(function(el){io.observe(el)});
}else{$$('.rv').forEach(function(el){el.classList.add('in')});}

/* inclinar os cartões de trabalho */
if(fino&&!reduz){$$('.work').forEach(function(el){
  el.addEventListener('pointermove',function(e){var r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;el.style.setProperty('--ry',(x*10)+'deg');el.style.setProperty('--rx',(-y*8)+'deg')});
  el.addEventListener('pointerleave',function(){el.style.setProperty('--rx','0deg');el.style.setProperty('--ry','0deg')});
});}

/* brilho que segue o mouse nos serviços */
$$('.srv').forEach(function(el){el.addEventListener('pointermove',function(e){var r=el.getBoundingClientRect();el.style.setProperty('--mx',(e.clientX-r.left)+'px');el.style.setProperty('--my',(e.clientY-r.top)+'px')})});

/* ver trabalho em tamanho grande */
var dlg=$('#dlg');
if(dlg){var di=$('#dimg'),dc=$('#dcap');
  $$('button.work').forEach(function(b){b.addEventListener('click',function(){var im=$('img',b);di.src=im.src;di.alt=im.alt;dc.textContent=b.dataset.title;dlg.showModal()})});
  $('#fechar').addEventListener('click',function(){dlg.close()});
  dlg.addEventListener('click',function(e){if(e.target===dlg)dlg.close()});
}

/* linha do tempo do processo */
var tl=$('.tl');
if(tl){var steps=$$('.step',tl);
  var upd=function(){var r=tl.getBoundingClientRect(),vh=innerHeight,p=Math.min(1,Math.max(0,(vh*.65-r.top)/r.height));tl.style.setProperty('--prog',p);steps.forEach(function(s){s.classList.toggle('on',s.getBoundingClientRect().top<vh*.65)})};
  addEventListener('scroll',upd,{passive:true});addEventListener('resize',upd);upd();
}

/* formulário de contato */
var f=$('#form');
if(f){var st=$('#status'),btn=$('#enviar');
  var burst=function(){if(reduz)return;var r=btn.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
    for(var i=0;i<14;i++){var b=d.createElement('span');b.className='burst';var a=Math.random()*Math.PI*2,k=90+Math.random()*180;
      b.style.left=(cx-17)+'px';b.style.top=(cy-15)+'px';b.style.setProperty('--dx',Math.cos(a)*k+'px');b.style.setProperty('--dy',(Math.sin(a)*k-60)+'px');b.style.setProperty('--rot',(Math.random()*80-40)+'deg');
      d.body.appendChild(b);setTimeout(function(x){return function(){x.remove()}}(b),1500);}};
  f.addEventListener('submit',function(e){e.preventDefault();btn.disabled=true;st.className='status';st.textContent='Enviando...';
    fetch('/',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(f)).toString()})
    .then(function(r){if(!r.ok)throw new Error();f.reset();st.className='status ok';st.textContent='Mensagem enviada! Vou responder pelo contato que você deixou.';burst()})
    .catch(function(){st.className='status';st.textContent='Não foi possível enviar agora. Tente de novo em instantes.'})
    .finally(function(){btn.disabled=false})});
}
})();
